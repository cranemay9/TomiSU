// Mirrored from compose-miuix-ui example.

package io.tomie.su.ui.component.miuix.effect

enum class DeviceType {
    PHONE,
    PAD,
}
