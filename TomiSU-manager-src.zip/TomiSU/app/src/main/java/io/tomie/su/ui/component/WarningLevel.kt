package io.tomie.su.ui.component

enum class WarningLevel { Error, Notice }
