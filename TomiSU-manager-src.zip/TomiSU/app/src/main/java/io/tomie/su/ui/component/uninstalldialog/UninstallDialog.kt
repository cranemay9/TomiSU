package io.tomie.su.ui.component.uninstalldialog

import androidx.compose.runtime.Composable
import io.tomie.su.ui.LocalUiMode
import io.tomie.su.ui.UiMode

@Composable
fun UninstallDialog(
    show: Boolean,
    onDismissRequest: () -> Unit
) {
    when (LocalUiMode.current) {
        UiMode.Miuix -> UninstallDialogMiuix(show, onDismissRequest)
        UiMode.Material -> UninstallDialogMaterial(show, onDismissRequest)
    }
}
