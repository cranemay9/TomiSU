package io.tomie.su.data.repository

import io.tomie.su.data.model.Module
import io.tomie.su.data.model.ModuleUpdateInfo

interface ModuleRepository {
    suspend fun getModules(): Result<List<Module>>
    suspend fun checkUpdate(module: Module): Result<ModuleUpdateInfo>
}
