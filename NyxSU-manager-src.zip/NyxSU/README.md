# NyxSU

NyxSU 是一个基于内核的 Android Root 管理器（Kernel-based root manager），由 KernelSU 的开源管理器（`manager/`）重新品牌化、重构而来。

> 名称：**NyxSU**（富江SU）  
> 包名：`io.nyx.su`  
> 原生库：`libnyxsu.so`  
> 上游：https://github.com/tiann/KernelSU （内核模块与 ksud 守护进程协议保持不变）

## 是什么

NyxSU 是 KernelSU 生态的管理端 App，负责：

- **超级用户（Superuser）管理**：授予 / 撤销 App 的 root 权限，配置每个 App 的 root 与非 root Profile（UID、GID、Capabilities、SELinux 上下文、umount 策略等）。
- **模块（Module）管理**：安装、启用、禁用、卸载、更新 Magisk 风格模块（`/data/adb/modules/`），执行模块生命周期脚本，管理 meta-module。
- **内核/守护进程通信**：通过 JNI（`libnyxsu.so`）调用内核 supercall IOCTL，通过 `ksud` 守护进程管理模块与 su 兼容层。
- **设置与日志**：su 兼容开关、SELinux hide、内核 umount、su 日志、安全模式、ADB Root 等。
- **模块仓库 / WebUI**：浏览官方模块仓库，加载模块的 WebUI。

## 与 KernelSU 的关系

NyxSU 是对 KernelSU `manager/` 子项目的完整品牌化重构：

| 项 | KernelSU 原版 | NyxSU |
| --- | --- | --- |
| 应用名 | KernelSU | NyxSU |
| rootProject | `KernelSU` | `NyxSU` |
| 包名 / namespace | `me.weishu.kernelsu` | `io.nyx.su` |
| JNI 库 | `libkernelsu.so` | `libnyxsu.so` |
| Application 类 | `KernelSUApplication` | `NyxSUApplication` |
| 主题 | `Theme.KernelSU` | `Theme.NyxSU` |
| C++ 日志 TAG | `KernelSU` | `NyxSU` |

**保持不变（协议/兼容性原因，不可修改）**：

- 内核 supercall IOCTL 常量（`KSU_IOCTL_*`、`KERNEL_SU_UAPI_VERSION` 等）
- SELinux domain（`u:r:ksu:s0`）
- ksud 二进制名（`libksud.so`）与 `/data/adb/ksu/` 路径
- 官方模块仓库域名（`Modules.KernelSU.org`）与模块 WebUI 域名（`mui.kernelsu.org`）
- `ksu://` deep-link scheme

## 目录结构

```
NyxSU/
├── app/
│   └── src/
│       ├── main/
│       │   ├── java/io/nyx/su/     # Kotlin 主代码
│       │   │   ├── Natives.kt        # 内核 supercall JNI 门面
│       │   │   ├── NyxSUApplication.kt
│       │   │   ├── core/             # 内核镜像 payload 处理
│       │   │   ├── data/             # 数据层（repository/registry/script）
│       │   │   ├── magica/           # App Zygote 提权服务
│       │   │   ├── profile/          # Root Profile 模型
│       │   │   └── ui/               # Compose UI（Material + Miuix）
│       │   ├── cpp/                  # JNI 桥接（nyxsu.so + adbroot.so）
│       │   ├── aidl/io/nyx/su/     # IKsuInterface.aidl
│       │   ├── proto/                # OTA payload protobuf
│       │   └── res/                  # 资源（多语言 strings）
│       └── test/                     # 单元测试
├── build.gradle.kts                  # 根构建脚本（SDK/NDK 版本、版本号）
├── settings.gradle.kts               # rootProject = NyxSU
└── gradle/                           # 版本目录 + wrapper
```

## 构建

### 前置条件

- Android SDK（compileSdk 37、buildTools 37.0.0）
- Android NDK（见 `gradle/libs.versions.toml` 中的 `ndk` 版本）
- JDK 21
- **ksud 二进制**：Manager 构建前必须把 `ksud` 放到 `jniLibs`（它作为 `libksud.so` 随 APK 分发，供 magica 提权服务 exec）

### 步骤

```bash
# 1. 编译 ksud（Rust，见上游 userspace/ksud）
cd ../userspace/ksud
cargo ndk -t arm64-v8a -o ../manager/app/src/main/jniLibs release

# 2. 拷贝 ksud 为 libksud.so
mkdir -p app/src/main/jniLibs/arm64-v8a
cp <ksud 产物> app/src/main/jniLibs/arm64-v8a/libksud.so

# 3. 构建
cd NyxSU
./gradlew clean assembleRelease
```

产物：`app/build/outputs/apk/release/NyxSU_<version>_<versionCode>.apk`

## 免责

本项目为 KernelSU 上游 manager 的品牌化重构，内核模块与 ksud 协议完全兼容上游，保留原作者版权与许可（GPL，见上游 LICENSE）。
