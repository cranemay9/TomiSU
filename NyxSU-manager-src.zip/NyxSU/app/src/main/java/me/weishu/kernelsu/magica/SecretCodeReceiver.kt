package me.weishu.kernelsu.magica

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Dial *#*#6997#*#* to launch NyxSU when the launcher icon is hidden.
 */
class SecretCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        runCatching {
            context.startActivity(
                Intent(context, Class.forName("me.weishu.kernelsu.ui.MainActivity"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
