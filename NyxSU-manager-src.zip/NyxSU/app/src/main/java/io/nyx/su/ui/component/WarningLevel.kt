package io.nyx.su.ui.component

enum class WarningLevel { Error, Notice }
