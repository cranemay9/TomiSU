// Mirrored from compose-miuix-ui example.

package io.nyx.su.ui.component.miuix.effect

enum class DeviceType {
    PHONE,
    PAD,
}
