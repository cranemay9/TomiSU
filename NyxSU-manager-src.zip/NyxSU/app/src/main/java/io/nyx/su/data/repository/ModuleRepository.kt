package io.nyx.su.data.repository

import io.nyx.su.data.model.Module
import io.nyx.su.data.model.ModuleUpdateInfo

interface ModuleRepository {
    suspend fun getModules(): Result<List<Module>>
    suspend fun checkUpdate(module: Module): Result<ModuleUpdateInfo>
}
