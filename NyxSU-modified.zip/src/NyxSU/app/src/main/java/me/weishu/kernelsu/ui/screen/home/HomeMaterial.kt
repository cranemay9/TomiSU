package me.weishu.kernelsu.ui.screen.home

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.topjohnwu.superuser.Shell
import me.weishu.kernelsu.Natives
import me.weishu.kernelsu.R
import me.weishu.kernelsu.ui.component.WarningLevel
import me.weishu.kernelsu.ui.component.material.ExpressiveScaffold
import me.weishu.kernelsu.ui.theme.LocalBgBlurLevel
import me.weishu.kernelsu.ui.theme.LocalGlassOpacity
import me.weishu.kernelsu.ui.theme.LocalUseWallpaperBg
import java.io.File

private val GreenLight = Color(0xFFDFF3E2)
private val GreenMid = Color(0xFFC2EAC8)
private val GreenAccent = Color(0xFF2FBF5B)
private val GrayLight = Color(0xFFE8E8EA)
private val GrayMid = Color(0xFFD9D9DE)

@Composable
fun HomePagerMaterial(
    state: HomeUiState,
    actions: HomeActions,
    bottomInnerPadding: Dp,
) {
    val glassOpacity = LocalGlassOpacity.current
    val bgBlurLevel = LocalBgBlurLevel.current
    val useWallpaperBg = LocalUseWallpaperBg.current
    val context = LocalContext.current

    val wallpaperBitmap = remember(useWallpaperBg) {
        if (!useWallpaperBg) null else runCatching {
            val wm = WallpaperManager.getInstance(context)
            val drawable = wm.drawable
            val src = (drawable as? BitmapDrawable)?.bitmap ?: return@runCatching null
            val maxSide = 720
            val scale = minOf(1f, maxSide.toFloat() / maxOf(src.width, src.height))
            Bitmap.createScaledBitmap(
                src,
                (src.width * scale).toInt().coerceAtLeast(1),
                (src.height * scale).toInt().coerceAtLeast(1),
                true
            )
        }.getOrNull()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        MaterialTheme.colorScheme.background
                    )
                )
            )
    ) {
        // blurred wallpaper layer (SukiSU style)
        if (wallpaperBitmap != null) {
            Image(
                bitmap = wallpaperBitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .blur(bgBlurLevel.dp)
            )
            // dark veil so text stays readable
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.15f),
                                MaterialTheme.colorScheme.background.copy(alpha = 0.55f)
                            )
                        )
                    )
            )
        }

        ExpressiveScaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing.only(
                WindowInsetsSides.Top + WindowInsetsSides.Horizontal
            )
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Spacer(Modifier.height(8.dp))

                Text(
                    text = "NyxSU",
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (state.checkUpdateEnabled) {
                    UpdateCard(state = state, actions = actions)
                }
                if (state.showManagerPrBuildWarning) {
                    WarningCard(stringResource(id = R.string.home_pr_build_warning), level = WarningLevel.Notice)
                } else if (state.showKernelPrBuildWarning) {
                    WarningCard(stringResource(id = R.string.home_pr_kernel_warning), level = WarningLevel.Notice)
                }
                if (state.requiresNewKernel) {
                    WarningCard(
                        stringResource(
                            id = if (state.canInstallKernelUpdate) R.string.require_kernel_version else R.string.require_kernel_version_gki
                        ),
                        onClick = if (state.canInstallKernelUpdate) actions.onInstallClick else null
                    )
                }
                if (state.requiresNewManager) {
                    WarningCard(stringResource(id = R.string.require_manager_version))
                }
                if (state.showRootWarning) {
                    WarningCard(stringResource(id = R.string.grant_root_failed))
                }

                StatusHeroCard(state = state, actions = actions)
                CountCardsRow(glassOpacity)
                InfoListCard(state = state, glassOpacity)

                Spacer(Modifier.height(bottomInnerPadding + 24.dp))
            }
        }
    }
}

@Composable
private fun StatusHeroCard(state: HomeUiState, actions: HomeActions) {
    val installed = state.ksuVersion != null
    val bg = if (installed) Brush.linearGradient(listOf(GreenLight, GreenMid))
    else Brush.linearGradient(listOf(GrayLight, GrayMid))

    val statusText = when {
        state.ksuVersion == null -> stringResource(R.string.home_not_installed)
        state.isSafeMode -> stringResource(R.string.home_working) + " (Safe)"
        else -> stringResource(R.string.home_working)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(bg, RoundedCornerShape(24.dp))
            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        if (installed) {
            Canvas(modifier = Modifier
                .align(Alignment.CenterEnd)
                .size(96.dp)
            ) {
                val stroke = 14.dp.toPx()
                drawArc(
                    color = GreenAccent,
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                val w = size.width
                val check = Path().apply {
                    moveTo(w * 0.28f, w * 0.52f)
                    lineTo(w * 0.45f, w * 0.68f)
                    lineTo(w * 0.74f, w * 0.34f)
                }
                drawPath(
                    check,
                    color = GreenAccent,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val lkmLabel = if (state.lkmMode == true) "LKM" else "Kernel"
                TagChip(text = lkmLabel, filled = installed)
                if (state.showCustomLkmBadge) {
                    TagChip(text = stringResource(R.string.home_lkm_custom), filled = false)
                }
                if (state.isLateLoadMode) {
                    TagChip(text = "Jailbreak", filled = false)
                }
                if (state.isSafeMode) {
                    TagChip(text = "SafeMode", filled = false)
                }
            }

            Spacer(Modifier.height(28.dp))

            Text(
                text = statusText,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B1B1F)
            )
            Text(
                text = if (installed) {
                    stringResource(R.string.home_working_version, state.ksuVersion.toString())
                } else {
                    stringResource(R.string.home_click_to_install)
                },
                fontSize = 14.sp,
                color = Color(0xFF3A3A3E)
            )
        }

        if (!installed) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clickable { actions.onInstallClick() }
            )
        }
    }
}

@Composable
private fun CountCardsRow(glassOpacity: Float) {
    val superuserCount = remember { Natives.getSuperuserCount() }
    var moduleCount by remember { mutableIntStateOf(-1) }
    LaunchedEffect(Unit) {
        moduleCount = runCatching {
            Shell.cmd("ls -d /data/adb/modules/* 2>/dev/null | wc -l")
                .exec().out.firstOrNull()?.trim()?.toIntOrNull() ?: -1
        }.getOrDefault(-1)
    }

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CountCard(
            modifier = Modifier.weight(1f),
            number = if (superuserCount > 0) superuserCount.toString() else "0",
            label = stringResource(R.string.superuser),
            glassOpacity = glassOpacity
        )
        CountCard(
            modifier = Modifier.weight(1f),
            number = if (moduleCount >= 0) moduleCount.toString() else "—",
            label = stringResource(R.string.module),
            glassOpacity = glassOpacity
        )
    }
}

@Composable
private fun CountCard(modifier: Modifier, number: String, label: String, glassOpacity: Float) {
    GlassBox(modifier = modifier, shape = RoundedCornerShape(20.dp), glassOpacity = glassOpacity) {
        Column(Modifier.padding(16.dp)) {
            Text(number, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun InfoListCard(state: HomeUiState, glassOpacity: Float) {
    val info = state.systemInfo
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    val uptime = remember { mutableStateOf("—") }
    LaunchedEffect(Unit) {
        uptime.value = runCatching {
            val seconds = File("/proc/uptime").readText().split(" ")[0].toFloat().toLong()
            formatUptime(seconds)
        }.getOrDefault("—")
    }

    val battery = remember { mutableStateOf("—") }
    val memory = remember { mutableStateOf("—") }
    val storage = remember { mutableStateOf("—") }
    LaunchedEffect(Unit) {
        battery.value = runCatching {
            val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
            val temp = intent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            val pct = if (scale > 0) level * 100 / scale else 0
            "$pct%  ${temp / 10f}°C"
        }.getOrDefault("—")
        memory.value = runCatching {
            val m = File("/proc/meminfo").readText()
            fun gb(key: String): Float {
                val line = m.lineSequence().firstOrNull { it.startsWith(key) } ?: return 0f
                return line.replace(Regex("[^0-9]"), "").toFloat() / 1024f / 1024f
            }
            val total = gb("MemTotal:")
            val avail = gb("MemAvailable:")
            String.format("%.1f / %.1f GB", total - avail, total)
        }.getOrDefault("—")
        storage.value = runCatching {
            val stat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            val gb = 1024.0 * 1024.0 * 1024.0
            String.format("%.1f / %.1f GB", (total - free) / gb, total / gb)
        }.getOrDefault("—")
    }

    val fullInfo = buildString {
        appendLine("Manager: ${info.managerVersion}")
        appendLine("Kernel: ${info.kernelVersion}")
        appendLine("Android: ${Build.VERSION.RELEASE}")
        appendLine("Device: ${info.deviceModel}")
        appendLine("CPU: ${System.getProperty("os.arch")} / ${Runtime.getRuntime().availableProcessors()} cores")
        appendLine("Fingerprint: ${info.fingerprint}")
        appendLine("SELinux: ${info.selinuxStatus}")
    }

    GlassBox(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), glassOpacity = glassOpacity) {
        Column(Modifier.padding(vertical = 4.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "NyxSU",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                IconButton(onClick = {
                    clipboard.setText(AnnotatedString(fullInfo))
                    copied = true
                    Toast.makeText(context, R.string.home_copied, Toast.LENGTH_SHORT).show()
                }) {
                    Icon(
                        if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                        contentDescription = stringResource(R.string.home_copy_info),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            InfoRow(stringResource(R.string.home_manager_version), info.managerVersion)
            InfoRow(stringResource(R.string.home_kernel), info.kernelVersion)
            InfoRow(stringResource(R.string.home_android_version), Build.VERSION.RELEASE)
            InfoRow(stringResource(R.string.home_device_model), info.deviceModel)
            InfoRow(stringResource(R.string.home_cpu_arch), System.getProperty("os.arch") ?: "—")
            InfoRow(stringResource(R.string.home_cpu_cores), Runtime.getRuntime().availableProcessors().toString())
            InfoRow(stringResource(R.string.home_uptime), uptime.value)
            InfoRow(stringResource(R.string.home_battery), battery.value)
            InfoRow(stringResource(R.string.home_memory), memory.value)
            InfoRow(stringResource(R.string.home_storage), storage.value)
            InfoRow(stringResource(R.string.home_soc), Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL)
            InfoRow(stringResource(R.string.home_fingerprint), info.fingerprint)
            InfoRow(stringResource(R.string.home_selinux_status), info.selinuxStatus)
            val seccompText = when (info.seccompStatus) {
                0 -> stringResource(R.string.seccomp_status_disabled)
                1 -> stringResource(R.string.seccomp_status_strict)
                2 -> stringResource(R.string.seccomp_status_filter)
                else -> stringResource(R.string.seccomp_status_not_supported)
            }
            InfoRow(stringResource(R.string.home_seccomp_status), seccompText, last = true)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, last: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(start = 24.dp)
        )
    }
    if (!last) {
        Box(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(0.5.dp)
                .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
        )
    }
}

@Composable
private fun GlassBox(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape,
    glassOpacity: Float,
    content: @Composable () -> Unit,
) {
    val clamped = glassOpacity.coerceIn(0.15f, 0.95f)
    Box(
        modifier = modifier
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.surface.copy(alpha = clamped),
                        MaterialTheme.colorScheme.surface.copy(alpha = (clamped * 0.7f).coerceAtMost(0.95f))
                    )
                ),
                shape
            )
            .border(1.dp, Color.White.copy(alpha = 0.4f), shape)
    ) {
        content()
    }
}

@Composable
private fun TagChip(text: String, filled: Boolean) {
    Box(
        modifier = Modifier
            .background(
                if (filled) GreenAccent else Color.White.copy(alpha = 0.75f),
                RoundedCornerShape(50)
            )
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = if (filled) Color.White else Color(0xFF1B1B1F)
        )
    }
}

@Composable
private fun WarningCard(
    message: String,
    level: WarningLevel = WarningLevel.Error,
    onClick: (() -> Unit)? = null,
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = when (level) {
                WarningLevel.Notice -> MaterialTheme.colorScheme.secondaryContainer
                else -> MaterialTheme.colorScheme.errorContainer
            }
        ),
        onClick = onClick ?: {}
    ) {
        Text(
            message,
            Modifier.padding(16.dp),
            fontSize = 14.sp
        )
    }
}

@Composable
private fun UpdateCard(state: HomeUiState, actions: HomeActions) {
    val uriHandler = LocalUriHandler.current
    if (state.hasUpdate) {
        WarningCard(
            message = stringResource(R.string.home_lkm_update_available),
            level = WarningLevel.Notice,
            onClick = {
                runCatching {
                    uriHandler.openUri("https://github.com/cranemay9/TomiSU/releases/latest")
                }
            }
        )
    }
}

private fun formatUptime(totalSeconds: Long): String {
    val days = totalSeconds / 86400
    val hours = (totalSeconds % 86400) / 3600
    val minutes = (totalSeconds % 3600) / 60
    return when {
        days > 0 -> "${days}d ${hours}h"
        hours > 0 -> "${hours}h ${minutes}m"
        else -> "${minutes}m"
    }
}
