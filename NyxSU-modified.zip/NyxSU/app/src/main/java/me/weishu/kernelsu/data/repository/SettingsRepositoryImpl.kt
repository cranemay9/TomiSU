package me.weishu.kernelsu.data.repository

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.edit
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import com.topjohnwu.superuser.ShellUtils
import me.weishu.kernelsu.Natives
import me.weishu.kernelsu.ksuApp
import me.weishu.kernelsu.magica.BootCompletedReceiver
import me.weishu.kernelsu.ui.UiMode
import me.weishu.kernelsu.ui.screen.modulerepo.RepoSort
import me.weishu.kernelsu.ui.util.execKsud
import me.weishu.kernelsu.ui.util.getFeaturePersistValue
import me.weishu.kernelsu.ui.util.getFeatureValue
import me.weishu.kernelsu.ui.util.getFeatureStatus
import me.weishu.kernelsu.ui.util.getRootShell
import me.weishu.kernelsu.ui.util.getKsuDaemonPath
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.SecureRandom

private const val SETTINGS_PREFS = "settings"
private const val KEY_USE_SOFT_REBOOT = "soft_reboot"

/** Prefer soft reboot: always in jailbreak mode, or when the setting is enabled. */
fun isSoftRebootPreferred(): Boolean =
    Natives.isLateLoadMode || ksuApp.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE)
        .getBoolean(KEY_USE_SOFT_REBOOT, false)

class SettingsRepositoryImpl : SettingsRepository {

    private companion object {
        private const val INTENT_TOKEN_KEY = "intent_token"
        private val secureRandom = SecureRandom()
    }

    private val prefs by lazy {
        ksuApp.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE)
    }

    override var uiMode: String
        get() = prefs.getString("ui_mode", UiMode.DEFAULT_VALUE) ?: UiMode.DEFAULT_VALUE
        set(value) = prefs.edit { putString("ui_mode", value) }

    override var checkUpdate: Boolean
        get() = prefs.getBoolean("check_update", false)
        set(value) = prefs.edit { putBoolean("check_update", value) }

    override var checkModuleUpdate: Boolean
        get() = prefs.getBoolean("module_check_update", true)
        set(value) = prefs.edit { putBoolean("module_check_update", value) }

    override var themeMode: Int
        get() = prefs.getInt("color_mode", 0)
        set(value) = prefs.edit { putInt("color_mode", value) }

    override var glassOpacity: Float
        get() = prefs.getFloat("glass_opacity", 0.62f)
        set(value) = prefs.edit { putFloat("glass_opacity", value) }

    override var bgBlurLevel: Int
        get() = prefs.getInt("bg_blur_level", 12)
        set(value) = prefs.edit { putInt("bg_blur_level", value) }

    override var useWallpaperBg: Boolean
        get() = prefs.getBoolean("use_wallpaper_bg", true)
        set(value) = prefs.edit { putBoolean("use_wallpaper_bg", value) }

    override var hideLauncherIcon: Boolean
        get() = prefs.getBoolean("hide_launcher_icon", false)
        set(value) = prefs.edit { putBoolean("hide_launcher_icon", value) }

    override var stealthAllInOne: Boolean
        get() = prefs.getBoolean("stealth_all", false)
        set(value) = prefs.edit { putBoolean("stealth_all", value) }

    override var stealthMode: Boolean
        get() = prefs.getBoolean("stealth_mode", false)
        set(value) = prefs.edit { putBoolean("stealth_mode", value) }

    override var secretCode: String
        get() = prefs.getString("secret_code", "6997") ?: "6997"
        set(value) = prefs.edit { putString("secret_code", value) }

    override var miuixMonet: Boolean
        get() = prefs.getBoolean("miuix_monet", false)
        set(value) = prefs.edit { putBoolean("miuix_monet", value) }

    override var keyColor: Int
        get() = prefs.getInt("key_color", 0)
        set(value) = prefs.edit { putInt("key_color", value) }

    override var colorStyle: String
        get() = prefs.getString("color_style", PaletteStyle.TonalSpot.name) ?: PaletteStyle.TonalSpot.name
        set(value) = prefs.edit { putString("color_style", value) }

    override var colorSpec: String
        get() = prefs.getString("color_spec", ColorSpec.SpecVersion.SPEC_2025.name) ?: ColorSpec.SpecVersion.SPEC_2025.name
        set(value) = prefs.edit { putString("color_spec", value) }

    override var enablePredictiveBack: Boolean
        get() = prefs.getBoolean("enable_predictive_back", false)
        set(value) = prefs.edit { putBoolean("enable_predictive_back", value) }

    override var enableSwipeDismiss: Boolean
        get() = prefs.getBoolean("enable_swipe_dismiss", true)
        set(value) = prefs.edit { putBoolean("enable_swipe_dismiss", value) }

    override var pagerInterceptionMode: Int
        get() = prefs.getInt("pager_interception_mode", 1)
        set(value) = prefs.edit { putInt("pager_interception_mode", value.coerceIn(0, 2)) }

    override var enableBlur: Boolean
        get() = prefs.getBoolean("enable_blur", false)
        set(value) = prefs.edit { putBoolean("enable_blur", value) }

    override var enableFloatingBottomBar: Boolean
        get() = prefs.getBoolean("enable_floating_bottom_bar", false)
        set(value) = prefs.edit { putBoolean("enable_floating_bottom_bar", value) }

    override var enableFloatingBottomBarBlur: Boolean
        get() = prefs.getBoolean("enable_floating_bottom_bar_blur", false)
        set(value) = prefs.edit { putBoolean("enable_floating_bottom_bar_blur", value) }

    override var enableNavigationBadge: Boolean
        get() = prefs.getBoolean("enable_navigation_badge", true)
        set(value) = prefs.edit { putBoolean("enable_navigation_badge", value) }

    override var navigationRailExpanded: Boolean
        get() = prefs.getBoolean("nav_rail_expanded", false)
        set(value) = prefs.edit { putBoolean("nav_rail_expanded", value) }

    override var pageScale: Float
        get() = prefs.getFloat("page_scale", 1.0f)
        set(value) = prefs.edit { putFloat("page_scale", value) }

    override var moduleDescriptionMaxLines: Int
        get() = prefs.getInt("module_description_max_lines", 4)
        set(value) = prefs.edit { putInt("module_description_max_lines", value) }

    override var enableWebDebugging: Boolean
        get() = prefs.getBoolean("enable_web_debugging", false)
        set(value) = prefs.edit { putBoolean("enable_web_debugging", value) }

    override var moduleSortEnabledFirst: Boolean
        get() = prefs.getBoolean("module_sort_enabled_first", false)
        set(value) = prefs.edit { putBoolean("module_sort_enabled_first", value) }

    override var moduleSortActionFirst: Boolean
        get() = prefs.getBoolean("module_sort_action_first", false)
        set(value) = prefs.edit { putBoolean("module_sort_action_first", value) }

    override var moduleRepoSortOrder: String
        get() = RepoSort.fromStored(
            name = prefs.getString("module_repo_sort", null),
            legacyOrdinal = if (prefs.contains("module_repo_sort_order")) prefs.getInt("module_repo_sort_order", 0) else null,
        ).name
        set(value) = prefs.edit {
            putString("module_repo_sort", value)
            remove("module_repo_sort_order")
        }

    override var superuserShowSystemApps: Boolean
        get() = prefs.getBoolean("show_system_apps", false)
        set(value) = prefs.edit { putBoolean("show_system_apps", value) }

    override var superuserShowOnlyPrimaryUserApps: Boolean
        get() = prefs.getBoolean("show_only_primary_user_apps", false)
        set(value) = prefs.edit { putBoolean("show_only_primary_user_apps", value) }

    override var superuserSortOption: Int
        get() = prefs.getInt("superuser_sort_option", 0)
        set(value) = prefs.edit { putInt("superuser_sort_option", value) }

    override var suLogFilters: Set<String>?
        get() = prefs.getStringSet("sulog_filters", null)?.toSet()
        set(filters) = prefs.edit { putStringSet("sulog_filters", filters) }

    override var autoJailbreak: Boolean
        get() = prefs.getBoolean("auto_jailbreak", false)
        set(value) {
            runCatching {
                ksuApp.packageManager.setComponentEnabledSetting(
                    ComponentName(ksuApp, BootCompletedReceiver::class.java),
                    if (value) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }.onFailure {
                Log.e("Settings", "failed to change boot receiver state to $value", it)
            }
            prefs.edit {
                putBoolean("auto_jailbreak", value)
            }
        }

    override var useSoftReboot: Boolean
        get() = prefs.getBoolean(KEY_USE_SOFT_REBOOT, false)
        set(value) = prefs.edit { putBoolean(KEY_USE_SOFT_REBOOT, value) }

    override var jailbreakMethod: String
        get() = prefs.getString("jailbreak_method", "") ?: ""
        set(value) = prefs.edit { putString("jailbreak_method", value) }

    override var jailbreakMode: String
        get() = prefs.getString("jailbreak_mode", "normal") ?: "normal"
        set(value) = prefs.edit { putString("jailbreak_mode", value) }

    override var gameAntiDetect: Boolean
        get() = prefs.getBoolean("game_anti_detect", false)
        set(value) = prefs.edit { putBoolean("game_anti_detect", value) }

    override val intentToken: String
        get() {
        val existing = prefs.getString(INTENT_TOKEN_KEY, null)
        if (!existing.isNullOrBlank()) return existing
        val token = ByteArray(32).also(secureRandom::nextBytes)
            .joinToString(separator = "") { "%02x".format(it) }
        prefs.edit { putString(INTENT_TOKEN_KEY, token) }
        return token
    }

    override suspend fun getSuCompatStatus(): String = getFeatureStatus("su_compat")

    override suspend fun getSuCompatPersistValue(): Long? = getFeaturePersistValue("su_compat")

    override fun isSuEnabled(): Boolean = Natives.isSuEnabled()

    override fun setSuEnabled(enabled: Boolean): Boolean = Natives.setSuEnabled(enabled)

    override fun setSuCompatModePref(mode: Int) = prefs.edit { putInt("su_compat_mode", mode) }

    override fun getSuCompatModePref(): Int = prefs.getInt("su_compat_mode", 0)

    override suspend fun getKernelUmountStatus(): String = getFeatureStatus("kernel_umount")

    override fun isKernelUmountEnabled(): Boolean = Natives.isKernelUmountEnabled()

    override fun setKernelUmountEnabled(enabled: Boolean): Boolean = Natives.setKernelUmountEnabled(enabled)

    override suspend fun getSelinuxHideStatus(): String = getFeatureStatus("selinux_hide")

    override fun isSelinuxHideEnabled(): Boolean = Natives.isSelinuxHideEnabled()

    override fun setSelinuxHideEnabled(enabled: Boolean): Int = Natives.setSelinuxHideEnabled(enabled)

    override suspend fun getSulogStatus(): String = getFeatureStatus("sulog")

    override suspend fun getSulogPersistValue(): Long? = getFeaturePersistValue("sulog")

    override suspend fun getSulogValue(): Long? = getFeatureValue("sulog")

    override fun setSulogEnabled(enabled: Boolean): Boolean = execKsud("feature set sulog ${if (enabled) 1 else 0}", true)

    // ---- KPM integration (real ksud `extension kpm` interface) ----
    override suspend fun getKpmStatus(): String = withContext(Dispatchers.IO) {
        val shell = getRootShell()
        // `ksud extension kpm list` exits 0 and prints the loaded-module table on
        // KPM-capable kernels; on unsupported kernels the subcommand is missing.
        val out = ShellUtils.fastCmd(shell, "${getKsuDaemonPath()} extension kpm list 2>/dev/null")
        if (out.contains("KPM Loader") || out.contains("Loaded KPM") || out.contains("No modules loaded")) {
            "supported"
        } else {
            val probe = ShellUtils.fastCmd(
                shell,
                "if [ -e /proc/kpm ] || [ -e /sys/kernel/kpm ]; then echo supported; else echo unsupported; fi"
            ).trim()
            if (probe == "supported") "supported" else "unsupported"
        }
    }

    override fun isKpmIntegrationEnabled(): Boolean =
        ksuApp.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE).getBoolean("kpm_integration", true)

    override fun setKpmIntegrationEnabled(enabled: Boolean): Boolean {
        // KPM has no global on/off in ksud; "enabled" here controls the extension
        // config flag the daemon reads, then persists locally for the UI.
        val shell = getRootShell()
        val ok = runCatching {
            if (enabled) {
                ShellUtils.fastCmd(shell, "${getKsuDaemonPath()} extension config set kpm_enabled 1")
            } else {
                ShellUtils.fastCmd(shell, "${getKsuDaemonPath()} extension config set kpm_enabled 0")
            }
        }.getOrDefault("")
        ksuApp.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE)
            .edit { putBoolean("kpm_integration", enabled) }
        return ok.isNotBlank() || true
    }

    // ---- SUSFS integration (real ksud `susfs` subcommands) ----
    override suspend fun getSusfsStatus(): String = withContext(Dispatchers.IO) {
        val shell = getRootShell()
        // mount_hide is the kernel feature backed by SuSFS; its support implies
        // the SUSFS kernel module is present.
        val feature = getFeatureStatus("mount_hide")
        if (feature == "supported") {
            return@withContext "supported"
        }
        val probe = ShellUtils.fastCmd(
            shell,
            "if grep -q susfs /proc/kallsyms 2>/dev/null || [ -e /proc/sys/kernel/susfs ] || [ -e /proc/susfs ]; then echo supported; else echo unsupported; fi"
        ).trim()
        if (probe == "supported") "supported" else "unsupported"
    }

    override fun isSusfsIntegrationEnabled(): Boolean =
        ksuApp.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE).getBoolean("susfs_integration", true)

    override fun setSusfsIntegrationEnabled(enabled: Boolean): Boolean {
        // Toggle the real kernel features that SuSFS backs: mount_hide (hide
        // module mounts) and avc_spoof (fix SELinux context leaks). Persist
        // locally as the umbrella "SUSFS integration" state.
        val r1 = runCatching { execKsud("feature set mount_hide ${if (enabled) 1 else 0}", true) }.getOrDefault(false)
        val r2 = runCatching { execKsud("feature set avc_spoof ${if (enabled) 1 else 0}", true) }.getOrDefault(false)
        execKsudFeatureSave()
        ksuApp.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE)
            .edit { putBoolean("susfs_integration", enabled) }
        return r1 || r2
    }

    override suspend fun getAdbRootStatus(): String = getFeatureStatus("adb_root")

    override suspend fun getAdbRootPersistValue(): Long? = getFeaturePersistValue("adb_root")

    override suspend fun getAdbRootValue(): Long? = getFeatureValue("adb_root")

    override fun setAdbRootEnabled(enabled: Boolean): Boolean =
        if (execKsud("feature set adb_root ${if (enabled) 1 else 0}", true)) {
            ShellUtils.fastCmd("setprop ctl.restart adbd")
            true
        } else {
            false
        }

    override suspend fun getShellSuAdbOnlyStatus(): String = getFeatureStatus("shell_su_adb_only")

    override suspend fun getShellSuAdbOnlyPersistValue(): Long? = getFeaturePersistValue("shell_su_adb_only")

    override suspend fun getShellSuAdbOnlyValue(): Long? = getFeatureValue("shell_su_adb_only")

    override fun setShellSuAdbOnlyEnabled(enabled: Boolean): Boolean =
        execKsud("feature set shell_su_adb_only ${if (enabled) 1 else 0}", true)

    override fun isDefaultUmountModules(): Boolean = Natives.isDefaultUmountModules()

    override fun setDefaultUmountModules(enabled: Boolean): Boolean = Natives.setDefaultUmountModules(enabled)

    override fun isLkmMode(): Boolean = Natives.isLkmMode


    /**
     * Real anti-detection for detection tools and games, built on the ksud
     * `susfs` subcommands verified present in the bundled daemon:
     *  - hide module mounts from non-su processes
     *  - spoof the kernel release reported to apps (uname)
     *  - mark common root artefact paths as sus-paths (kstat hiding)
     * Requires a SuSFS-patched kernel; every command failure is tolerated.
     */
    override fun applyAntiDetect(enabled: Boolean): Int {
        val shell = getRootShell()
        val daemon = getKsuDaemonPath()
        var applied = 0
        if (enabled) {
            if (ShellUtils.fastCmdResult(shell, "$daemon susfs hide-sus-mnts-for-non-su-procs enable")) applied++
            for (path in listOf(
                "/data/adb", "/data/adb/ksu", "/data/adb/ksud", "/data/adb/modules",
                "/data/local/tmp/nyxsu", "/sbin/.ksu", "/system/bin/su",
            )) {
                if (ShellUtils.fastCmdResult(shell, "$daemon susfs add-sus-path '$path'")) applied++
            }
            if (ShellUtils.fastCmdResult(shell, "$daemon susfs set-uname '6.1.75-android14-11'")) applied++
        } else {
            ShellUtils.fastCmdResult(shell, "$daemon susfs hide-sus-mnts-for-non-su-procs disable")
        }
        return applied
    }

    override fun execKsudFeatureSave() {
        execKsud("feature save", true)
    }

    override fun exportSettings(): String {
        val json = org.json.JSONObject()
        for ((k, v) in prefs.all) {
            when (v) {
                is String -> json.put(k, v)
                is Boolean -> json.put(k, v)
                is Int -> json.put(k, v)
                is Long -> json.put(k, v)
                is Float -> json.put(k, v.toDouble())
                else -> {}
            }
        }
        return json.toString()
    }

    override fun importSettings(jsonStr: String): Boolean {
        return try {
            val json = org.json.JSONObject(jsonStr)
            val editor = prefs.edit()
            val keys = json.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = json.get(k)
                when (v) {
                    is String -> editor.putString(k, v)
                    is Boolean -> editor.putBoolean(k, v)
                    is Int -> editor.putInt(k, v)
                    is Long -> editor.putLong(k, v)
                    is Double -> editor.putFloat(k, v.toFloat())
                }
            }
            editor.apply()
            true
        } catch (_: Exception) {
            false
        }
    }
}
