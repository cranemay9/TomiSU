package me.weishu.kernelsu

import android.app.Application
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.UserManager
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import me.weishu.kernelsu.magica.SecretCodeReceiver
import android.system.Os
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import me.weishu.kernelsu.data.repository.SettingsRepositoryImpl
import me.weishu.kernelsu.ui.viewmodel.SuperUserViewModel
import okhttp3.Cache
import okhttp3.OkHttpClient
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.io.File
import java.util.Locale

lateinit var ksuApp: NyxSUApplication

class NyxSUApplication : Application(), ViewModelStoreOwner {

    companion object {
        fun setEnableOnBackInvokedCallback(appInfo: ApplicationInfo, enable: Boolean) {
            runCatching {
                val applicationInfoClass = ApplicationInfo::class.java
                val method = applicationInfoClass.getDeclaredMethod("setEnableOnBackInvokedCallback", Boolean::class.javaPrimitiveType)
                method.isAccessible = true
                method.invoke(appInfo, enable)
            }
        }
    }

    lateinit var okhttpClient: OkHttpClient
    private var secretCodeReceiver: SecretCodeReceiver? = null

    private fun installCrashLogger() {
        val dir = getFilesDir()
        if (dir == null) return
        val logFile = java.io.File(dir, "crash.log")
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                logFile.appendText(
                    "===== " + java.util.Date() + " thread=" + (t?.name ?: "?") + " =====\n" +
                    android.util.Log.getStackTraceString(e) + "\n\n"
                )
            }
            val prev = Thread.getDefaultUncaughtExceptionHandler()
            prev?.uncaughtException(t, e)
        }
    }

    fun updateSecretCodeReceiver(code: String) {
        runCatching {
            secretCodeReceiver?.let { unregisterReceiver(it) }
            secretCodeReceiver = SecretCodeReceiver()
            val filter = IntentFilter("android.provider.Telephony.Sms.Intents.SECRET_CODE_ACTION")
            filter.addDataScheme("android_secret_code")
            filter.addDataAuthority(code.ifBlank { "6997" }, null)
            ContextCompat.registerReceiver(this, secretCodeReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
        }
    }
    private val appViewModelStore by lazy { ViewModelStore() }

    private fun isUserUnlocked(): Boolean =
        getSystemService(UserManager::class.java)?.isUserUnlocked == true

    override fun onCreate() {
        super.onCreate()
        ksuApp = this
        installCrashLogger()
        updateSecretCodeReceiver(SettingsRepositoryImpl().secretCode)

        if (!isUserUnlocked()) {
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val enable = SettingsRepositoryImpl().enablePredictiveBack
            HiddenApiBypass.addHiddenApiExemptions("Landroid/content/pm/ApplicationInfo;->setEnableOnBackInvokedCallback")
            setEnableOnBackInvokedCallback(applicationInfo, enable)
        }

        val superUserViewModel = ViewModelProvider(this)[SuperUserViewModel::class.java]
        superUserViewModel.loadAppList()

        val webroot = File(dataDir, "webroot")
        if (!webroot.exists()) {
            webroot.mkdir()
        }

        // Provide working env for rust's temp_dir()
        Os.setenv("TMPDIR", cacheDir.absolutePath, true)

        okhttpClient =
            OkHttpClient.Builder().cache(Cache(File(cacheDir, "okhttp"), 10 * 1024 * 1024))
                .addInterceptor { block ->
                    block.proceed(
                        block.request().newBuilder()
                            .header("User-Agent", "NyxSU/${BuildConfig.VERSION_CODE}")
                            .header("Accept-Language", Locale.getDefault().toLanguageTag()).build()
                    )
                }.build()
    }

    override val viewModelStore: ViewModelStore
        get() = appViewModelStore
}
