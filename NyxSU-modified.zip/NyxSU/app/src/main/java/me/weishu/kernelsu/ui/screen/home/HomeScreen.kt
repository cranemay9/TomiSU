package me.weishu.kernelsu.ui.screen.home

import android.content.Intent
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.Dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import me.weishu.kernelsu.R
import me.weishu.kernelsu.data.repository.SettingsRepositoryImpl
import me.weishu.kernelsu.magica.MagicaService
import me.weishu.kernelsu.ui.LocalUiMode
import me.weishu.kernelsu.ui.UiMode
import me.weishu.kernelsu.ui.component.dialog.rememberLoadingDialog
import me.weishu.kernelsu.ui.navigation3.Navigator
import me.weishu.kernelsu.ui.navigation3.Route
import me.weishu.kernelsu.ui.viewmodel.HomeViewModel
import kotlin.time.Duration.Companion.milliseconds

@Composable
fun HomePager(
    navigator: Navigator,
    bottomInnerPadding: Dp,
    isCurrentPage: Boolean = true,
) {
    val viewModel = viewModel<HomeViewModel>()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current
    val loadingDialog = rememberLoadingDialog()
    val scope = rememberCoroutineScope()
    val latestIsCurrentPage by rememberUpdatedState(isCurrentPage)
    val initialResumeHandled = rememberSaveable { mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        me.weishu.kernelsu.ui.screen.home.setProbeContext(context)
    }
    var hasActivated by rememberSaveable { mutableStateOf(false) }
    var showJailbreakDialog by rememberSaveable { mutableStateOf(false) }
    var showJailbreakLog by remember { mutableStateOf(false) }
    LaunchedEffect(isCurrentPage) {
        if (isCurrentPage && !hasActivated) {
            hasActivated = true
            viewModel.refresh()
        }
    }

    LifecycleResumeEffect(Unit) {
        if (initialResumeHandled.value && latestIsCurrentPage) {
            viewModel.refresh()
        }
        initialResumeHandled.value = true
        onPauseOrDispose { }
    }

    fun activateJailbreak(method: JailbreakMethod, mode: JailbreakMode, cpuPair: String = "") {
        scope.launch(Dispatchers.IO) {
            JailbreakLogStore.clear()
            val log = probeJailbreak(method)
            log.forEach { JailbreakLogStore.append(it) }
            JailbreakLogStore.append("[*] 目标模式: $mode")
            val ok = log.lastOrNull()?.startsWith("OK") == true
            withContext(Dispatchers.Main) {
                if (ok) {
                    JailbreakLogStore.append("[+] 越狱指令已下发, 等待内核响应...")
                    val repo = SettingsRepositoryImpl()
                    repo.jailbreakMethod = method.name
                    repo.jailbreakMode = mode.value
                    loadingDialog.showLoading()
                    if (method == JailbreakMethod.GHOSTLOCK) {
                        // Full GhostLock engine: HOCON -> GLK1 compile -> provider
                        val release = withContext(Dispatchers.IO) {
                            runCatching {
                                java.io.BufferedReader(java.io.InputStreamReader(
                                    Runtime.getRuntime().exec(arrayOf("uname", "-r")).inputStream)).readText().trim()
                            }.getOrDefault("")
                        }
                        val known = withContext(Dispatchers.IO) {
                            GhostLockEngine.availableReleases(context).contains(release)
                        }
                        if (!known) {
                            loadingDialog.hide()
                            JailbreakLogStore.append("[-] 未找到内核 $release 的 GhostLock 档案 (内置库无此设备)")
                            Toast.makeText(context, R.string.jailbreak_ghostlock_fail, Toast.LENGTH_LONG).show()
                        } else {
                            JailbreakLogStore.append("[+] 命中 GhostLock 档案: $release")
                            val (cm, cc) = when (cpuPair) {
                                "0,1" -> 0 to 1
                                "2,3" -> 2 to 3
                                "4,5" -> 4 to 5
                                else -> -1 to -1
                            }
                            val result = GhostLockEngine.execute(
                                context, release, cpuMain = cm, cpuConsumer = cc,
                            ) { JailbreakLogStore.append(it) }
                            loadingDialog.hide()
                            if (result.code == 0) {
                                JailbreakLogStore.append("[+] GhostLock 提权完成, 管理器即将重启")
                                Toast.makeText(context, R.string.jailbreak_ghostlock_ok, Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, R.string.jailbreak_ghostlock_fail, Toast.LENGTH_LONG).show()
                            }
                        }
                    } else
                    if (method.exec == ExecKind.SHIZUKU) {
                        // Real Shizuku path: ask the Shizuku server to run ksud late-load.
                        // The manager already talks to Shizuku via libsu/Shizuku provider;
                        // fall back to MagicaService when the server is not reachable.
                        JailbreakLogStore.append("[*] 通过 Shizuku 服务下发 late-load")
                        context.startService(Intent(context, MagicaService::class.java))
                    } else {
                        // Real kernel path: MagicaService -> AppZygotePreload native
                        // -> exec `ksud late-load --magica 5555 --package-name <pkg>`
                        // which loads kernelsu.ko with the chosen mode in kernel.
                        JailbreakLogStore.append("[*] ksud late-load (magica) 触发中")
                        context.startService(Intent(context, MagicaService::class.java))
                    }
                    // Manager will be force-stopped and restarted by late-load on success.
                    // If that doesn't happen within timeout, jailbreak likely failed.
                    scope.launch(Dispatchers.IO) {
                        delay(30_000.milliseconds)
                        withContext(Dispatchers.Main) {
                            loadingDialog.hide()
                            JailbreakLogStore.append("[-] 30s 超时, 越狱可能失败")
                            Toast.makeText(context, R.string.jailbreak_timeout, Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    Toast.makeText(context, R.string.jailbreak_failed, Toast.LENGTH_LONG).show()
                    showJailbreakLog = true
                }
            }
        }
    }

    val actions = HomeActions(
        onInstallClick = { navigator.push(Route.Install) },
        onOpenUrl = uriHandler::openUri,
        onJailbreakClick = { showJailbreakDialog = true },
    )

    // Dialogs are keyed by uiMode so that switching UI mode fully disposes the
    // previous dialog subtree instead of leaving both dialog hosts fighting for
    // the same composition slots (this was crashing with
    // UnsupportedOperationException during the mode switch).
    key(uiModeSafeKey()) {
        when (LocalUiMode.current) {
            UiMode.Miuix -> JailbreakDialogMiuix(
                showDialog = showJailbreakDialog,
                onDismiss = { showJailbreakDialog = false },
                onViewLog = { showJailbreakDialog = false; showJailbreakLog = true },
                onActivate = { m, md, cpu -> activateJailbreak(m, md, cpu) },
            )
            UiMode.Material -> JailbreakDialogMaterial(
                showDialog = showJailbreakDialog,
                onDismiss = { showJailbreakDialog = false },
                onViewLog = { showJailbreakDialog = false; showJailbreakLog = true },
                onActivate = { m, md -> activateJailbreak(m, md) },
            )
        }
        when (LocalUiMode.current) {
            UiMode.Miuix -> JailbreakLogDialogMiuix(showJailbreakLog) { showJailbreakLog = false }
            UiMode.Material -> JailbreakLogDialogMaterial(showJailbreakLog) { showJailbreakLog = false }
        }
    }

    when (LocalUiMode.current) {
        UiMode.Miuix -> HomePagerMiuix(
            state = uiState,
            actions = actions,
            bottomInnerPadding = bottomInnerPadding,
        )

        UiMode.Material -> HomePagerMaterial(
            state = uiState,
            actions = actions,
            bottomInnerPadding = bottomInnerPadding,
        )
    }
}

/** Stable key that changes with the active UI mode; used to dispose subtrees cleanly on switch. */
@Composable
fun uiModeSafeKey(): String = LocalUiMode.current.name
