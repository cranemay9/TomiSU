package me.weishu.kernelsu.ui.screen.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import top.yukonga.miuix.kmp.basic.Button
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text as M3Text
import androidx.compose.material3.TextButton as M3TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import me.weishu.kernelsu.R
import me.weishu.kernelsu.ui.theme.isInDarkTheme
import top.yukonga.miuix.kmp.basic.Card
import androidx.compose.foundation.layout.height
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import top.yukonga.miuix.kmp.basic.Text as MiuixText
import top.yukonga.miuix.kmp.basic.TextButton as MiuixTextButton
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.window.WindowDialog

/**
 * Jailbreak method picker dialog, mirroring the MapleSU-style flow:
 * method (DirtyFrag / Ghostlock / GhostKey / DirtyPipe / DirtyCow / Shizuku)
 * + target working mode (Ultra / Normal) + live log entry point.
 */

@Composable
private fun MethodRowMiuix(
    title: String,
    summary: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(modifier = Modifier.padding(start = 8.dp)) {
            MiuixText(
                text = title,
                fontSize = 16.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                color = MiuixTheme.colorScheme.onSurface,
            )
            if (summary.isNotBlank()) {
                MiuixText(
                    text = summary,
                    fontSize = 12.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )
            }
        }
    }
}

@Composable
fun JailbreakDialogMiuix(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    onViewLog: () -> Unit,
    onActivate: (JailbreakMethod, JailbreakMode, String) -> Unit,
) {
    if (!showDialog) return
    var method by remember { mutableStateOf(JailbreakMethod.DIRTY_FRAG) }
    var mode by remember { mutableStateOf(JailbreakMode.NORMAL) }
    var cpuPair by remember { mutableStateOf("") }
    WindowDialog(
        show = showDialog,
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
            ) {
                MiuixText(
                    text = stringResource(R.string.jailbreak_title),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MiuixTheme.colorScheme.onSurface,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                )
                MiuixText(
                    text = stringResource(R.string.jailbreak_subtitle),
                    fontSize = 13.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(top = 6.dp, bottom = 8.dp),
                )
                MiuixTextButton(
                    text = stringResource(R.string.jailbreak_view_log),
                    onClick = onViewLog,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColors(),
                )
                MiuixText(
                    text = stringResource(R.string.jailbreak_select_method),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MiuixTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 6.dp),
                )
                JailbreakMethod.entries.forEach { m ->
                    MethodRowMiuix(
                        title = stringResource(m.labelRes),
                        summary = stringResource(m.descRes),
                        selected = method == m,
                        onClick = { method = m },
                    )
                }
                if (method == JailbreakMethod.GHOSTLOCK) {
                    MiuixText(
                        text = "CPU 核心组",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MiuixTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
                    )
                    OverlayDropdownPreference(
                        title = "CPU 核心组",
                        summary = "提权线程绑定的核心 (默认自动)",
                        items = listOf("自动", "0,1 (小核)", "2,3 (大核)", "4,5 (超大核)"),
                        selectedIndex = when (cpuPair) {
                            "0,1" -> 1; "2,3" -> 2; "4,5" -> 3; else -> 0
                        },
                        onSelectedIndexChange = { idx ->
                            cpuPair = when (idx) { 1 -> "0,1"; 2 -> "2,3"; 3 -> "4,5"; else -> "" }
                        },
                    )
                    MiuixText(
                        text = "利用路径",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MiuixTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
                    )
                    MiuixText(
                        text = "TCP 零拷贝 (失败自动回退 select 栈) — 按档案库配置自动执行",
                        fontSize = 11.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                }
                MiuixText(
                    text = stringResource(R.string.jailbreak_select_mode),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MiuixTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 6.dp),
                )
                JailbreakMode.entries.forEach { md ->
                    MethodRowMiuix(
                        title = stringResource(md.labelRes),
                        summary = "",
                        selected = mode == md,
                        onClick = { mode = md },
                    )
                }
                MiuixText(
                    text = stringResource(R.string.jailbreak_activate_hint),
                    fontSize = 12.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(top = 6.dp, bottom = 4.dp),
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    MiuixTextButton(
                        text = stringResource(R.string.jailbreak_cancel),
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColors(),
                    )
                    MiuixTextButton(
                        text = stringResource(R.string.jailbreak_activate),
                        onClick = { onDismiss(); onActivate(method, mode, cpuPair) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary(),
                    )
                }
            }
        },
    )
}

@Composable
private fun MethodRowMaterial(
    title: String,
    summary: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(modifier = Modifier.padding(start = 8.dp)) {
            M3Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                color = Color.Unspecified,
            )
            if (summary.isNotBlank()) {
                M3Text(text = summary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun JailbreakDialogMaterial(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    onViewLog: () -> Unit,
    onActivate: (JailbreakMethod, JailbreakMode) -> Unit,
) {
    if (!showDialog) return
    var method by remember { mutableStateOf(JailbreakMethod.DIRTY_FRAG) }
    var mode by remember { mutableStateOf(JailbreakMode.NORMAL) }
    var cpuPair by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { M3Text(stringResource(R.string.jailbreak_title)) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                M3Text(
                    text = stringResource(R.string.jailbreak_subtitle),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
                M3TextButton(onClick = onViewLog) {
                    M3Text(stringResource(R.string.jailbreak_view_log))
                }
                M3Text(
                    text = stringResource(R.string.jailbreak_select_method),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp),
                )
                JailbreakMethod.entries.forEach { m ->
                    MethodRowMaterial(
                        title = stringResource(m.labelRes),
                        summary = stringResource(m.descRes),
                        selected = method == m,
                        onClick = { method = m },
                    )
                }
                M3Text(
                    text = stringResource(R.string.jailbreak_select_mode),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp),
                )
                JailbreakMode.entries.forEach { md ->
                    MethodRowMaterial(
                        title = stringResource(md.labelRes),
                        summary = "",
                        selected = mode == md,
                        onClick = { mode = md },
                    )
                }
                M3Text(
                    text = stringResource(R.string.jailbreak_activate_hint),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        },
        confirmButton = {
            M3TextButton(onClick = { onDismiss(); onActivate(method, mode) }) {
                M3Text(stringResource(R.string.jailbreak_activate))
            }
        },
        dismissButton = {
            M3TextButton(onClick = onDismiss) {
                M3Text(stringResource(R.string.jailbreak_cancel))
            }
        },
    )
}

/** Simple log viewer shared by both UI modes. */
@Composable
fun JailbreakLogDialogMaterial(show: Boolean, onDismiss: () -> Unit) {
    if (!show) return
    val log = remember { JailbreakLogStore.snapshot() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { M3Text(stringResource(R.string.jailbreak_log_title)) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                M3Text(
                    text = if (log.isEmpty()) stringResource(R.string.jailbreak_log_empty) else log.joinToString("\n"),
                    fontSize = 12.sp,
                )
            }
        },
        confirmButton = {
            M3TextButton(onClick = onDismiss) { M3Text(stringResource(R.string.jailbreak_log_close)) }
        },
    )
}

@Composable
fun JailbreakLogDialogMiuix(show: Boolean, onDismiss: () -> Unit) {
    if (!show) return
    val log = remember { JailbreakLogStore.snapshot() }
    val ok = log.lastOrNull()?.startsWith("OK") == true
    val statusColor = when {
        log.isEmpty() -> MiuixTheme.colorScheme.onSurfaceVariantSummary
        ok -> Color(0xFF2EE6A8)
        else -> Color(0xFFFF4D6D)
    }
    val statusText = when {
        log.isEmpty() -> "等待执行"
        ok -> "✓ 支持当前内核"
        else -> "✗ 当前内核不支持"
    }
    WindowDialog(
        show = show,
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
            ) {
                // 状态头: 大圆角卡片, 左状态色条 + 大标题
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(statusColor.copy(alpha = 0.12f))
                        .padding(14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(width = 4.dp, height = 34.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(statusColor),
                        )
                        Column(modifier = Modifier.padding(start = 12.dp)) {
                            MiuixText(
                                text = stringResource(R.string.jailbreak_log_title),
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = MiuixTheme.colorScheme.onSurface,
                            )
                            MiuixText(
                                text = statusText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = statusColor,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                // 日志行: 按前缀染色, 等宽感
                if (log.isEmpty()) {
                    MiuixText(
                        text = stringResource(R.string.jailbreak_log_empty),
                        fontSize = 13.sp,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                } else {
                    log.forEach { line ->
                        val lineColor = when {
                            line.startsWith("[+]") || line.startsWith("[✓]") -> Color(0xFF2EE6A8)
                            line.startsWith("[-]") || line.startsWith("FAIL") -> Color(0xFFFF6B81)
                            line.startsWith("OK") -> Color(0xFF2EE6A8)
                            else -> MiuixTheme.colorScheme.onSurface.copy(alpha = 0.78f)
                        }
                        MiuixText(
                            text = line,
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = lineColor,
                            modifier = Modifier.padding(vertical = 2.dp),
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                ) {
                    MiuixText(
                        text = stringResource(R.string.jailbreak_log_close),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                    )
                }
            }
        },
    )
}
