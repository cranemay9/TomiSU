package me.weishu.kernelsu.ui.screen.home

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.lsposed.lsprivilege.data.HoconSupport
import org.lsposed.lsprivilege.data.ValueMap
import org.lsposed.lsprivilege.data.asValueMap
import org.lsposed.lsprivilege.data.NativeProfileDocument
import org.lsposed.lsprivilege.data.route.RouteKind
import java.io.File

/**
 * Full GhostLock execution engine (ported from the open-source ghostlock-app):
 * HOCON profile -> resolve/merge -> GLK1 v3 binary -> provider process.
 *
 * The bundled provider (libmaplesu_ghostlock_provider.so) speaks the same
 * PRIV1 protocol as the upstream liblsprivilege.so: it takes the profile
 * binary on stdin with a length-prefixed frame and drives the kernel exploit.
 */
object GhostLockEngine {

    const val STAGE_DIR = "/data/local/tmp/nyxsu"

    // ---- profile resolution (mirrors ghostlock-app runtime path) ----

    private fun parseAsset(context: Context, path: String): ValueMap? {
        val base = "nyxsu/ghostlock/"
        val raw = context.assets.open(base + path).bufferedReader().readText()
        val expanded = expandIncludes(raw, base, HashSet())
        return runCatching { HoconSupport.parseValue(expanded).asValueMap() }.getOrNull()
    }

    private fun expandIncludes(text: String, base: String, visiting: MutableSet<String>): String {
        val out = StringBuilder()
        for (line in text.lineSequence()) {
            val t = line.trim()
            val target = when {
                t.startsWith("#") || t.startsWith("//") -> null
                t.startsWith("include ") -> t.removePrefix("include ").trim().trim('"')
                    .takeIf { it.isNotEmpty() && visiting.add(it) }
                else -> null
            }
            if (target == null) out.append(line).append('\n')
            else {
                try {
                    out.append(expandIncludes(
                        context0.assets.open(base + target).bufferedReader().readText(),
                        base, visiting)).append('\n')
                } catch (_: Exception) { }
            }
        }
        return out.toString()
    }

    @Volatile private lateinit var context0: Context
    fun initContext(c: Context) { context0 = c.applicationContext }

    /** List bundled profiles. */
    fun availableReleases(context: Context): List<String> =
        (context.assets.list("nyxsu/ghostlock") ?: arrayOf())
            .filter { it.endsWith(".conf") && !it.contains("template") }
            .map { it.removeSuffix(".conf") }

    private fun routeNameOf(profile: ValueMap, routes: List<String>): String? =
        when (val r = profile["route"]) {
            is String -> r.takeIf { it.isNotEmpty() && r != "null" }
            is Map<*, *> -> r.keys.filterIsInstance<String>().firstOrNull { it in routes }
            else -> null
        }

    private fun fallbackOf(profile: ValueMap): String? {
        val fb = profile["fallback"] as? Map<*, *> ?: return null
        return (fb["to"] as? String)?.takeIf { it.isNotEmpty() && it != "null" }
    }

    /**
     * Compile a HOCON profile into the GLK1 v3 binary document.
     * `cpuMain`/`cpuConsumer` override the execution CPU pair shown in the UI;
     * pass -1 to use profile defaults.
     */
    fun compileProfile(
        context: Context,
        release: String,
        cpuMain: Int = -1,
        cpuConsumer: Int = -1,
    ): ByteArray? = runCatching {
        val file = "$release.conf"
        val parsed = parseAsset(context, file) ?: return null
        val actual = parsed["release"] as? String ?: return null
        val routes = RouteKind.entries.map { it.token }
        val route = routeNameOf(parsed, routes)
        val fallbackTo = fallbackOf(parsed)

        val doc = NativeProfileDocument.from(
            release = actual,
            route = RouteKind.fromToken(route)?.token,
            fallbackTo = RouteKind.fromToken(fallbackTo)?.token,
        ) { path ->
            val keys = path.split('.')
            var cur: Any? = parsed
            for (k in keys) {
                cur = when (cur) {
                    is Map<*, *> -> (cur as Map<*, *>)[k]
                    else -> null
                }
            }
            val v = when (cur) {
                is Number -> cur.toLong()
                is String -> cur.toLongOrNull()
                else -> null
            }
            // CPU pair override hooks (execution.recommended_cpus)
            if (cpuMain >= 0 && path == "execution.recommended_cpus.main") cpuMain.toLong()
            else if (cpuConsumer >= 0 && path == "execution.recommended_cpus.consumer") cpuConsumer.toLong()
            else v
        }
        doc.toBinary()
    }.getOrNull()

    // ---- execution ----

    data class ExecResult(val code: Int, val log: List<String>)

    /**
     * Stage binaries + compiled profile and execute the GhostLock provider
     * through a root shell. The provider reads the GLK1 document on stdin
     * (length-prefixed PRIV1 frame) and drives the kernel exploit, printing
     * live status lines we relay into the jailbreak log.
     */
    suspend fun execute(
        context: Context,
        release: String,
        cpuMain: Int = -1,
        cpuConsumer: Int = -1,
        onLog: (String) -> Unit,
    ): ExecResult = withContext(Dispatchers.IO) {
        initContext(context)
        val log = mutableListOf<String>()
        fun L(s: String) { log.add(s); onLog(s) }

        // 1) stage binaries
        if (!JailbreakAssets.stageBinaries(context) { L(it) }) {
            return@withContext ExecResult(-1, log)
        }

        // 2) compile profile -> GLK1 blob
        L("[*] 编译 GhostLock 档案: $release")
        val blob = compileProfile(context, release, cpuMain, cpuConsumer)
        if (blob == null) {
            L("[-] 档案编译失败 (conf 不完整或缺字段)")
            return@withContext ExecResult(-2, log)
        }
        L("[+] GLK1 二进制生成: ${blob.size} 字节")

        val dir = File(STAGE_DIR).also { it.mkdirs() }
        val bin = File(dir, "ghostlock_profile.bin")
        bin.writeBytes(blob)
        val provider = File(dir, "ghostlock_provider.so")
        L("[*] Provider: $STAGE_DIR/ghostlock_provider.so")

        // 3) execute via root shell with stdin frame
        //    PRIV1 protocol: [4-byte LE length][blob] on stdin
        val framed = StringBuilder().also { sb ->
            val len = blob.size
            sb.appendCodePoint((len ushr 24) and 0xff)
            sb.appendCodePoint((len ushr 16) and 0xff)
            sb.appendCodePoint((len ushr 8) and 0xff)
            sb.appendCodePoint(len and 0xff)
        }
        val cmd = buildString {
            append("chmod 700 ${provider.absolutePath}; ")
            append("LSPRIVILEGE_HOME=$STAGE_DIR TMPDIR=$STAGE_DIR ")
            append("LSPRIVILEGE_KSUD=\$(command -v /data/adb/ksud || true) ")
            append("printf '%s' 'PRIV1' | head -c 0; ")
            append("$STAGE_DIR/ghostlock_provider.so --ghostlock-app-call --enable-status-record")
        }
        L("[*] 启动 provider (stdin: GLK1 frame)")

        try {
            val pb = ProcessBuilder("su", "-c", cmd)
                .directory(dir)
                .redirectErrorStream(true)
            val p = pb.start()
            // feed the framed blob on stdin
            val stdin = p.outputStream
            // PRIV1 magic + 4-byte length + blob
            stdin.write("PRIV1".toByteArray())
            stdin.write(byteArrayOf(
                (blob.size ushr 24).toByte(), (blob.size ushr 16).toByte(),
                (blob.size ushr 8).toByte(), blob.size.toByte(),
            ))
            stdin.write(blob)
            stdin.flush()
            stdin.close()

            val out = p.inputStream.bufferedReader().readLines()
            p.waitFor()
            out.forEach { line ->
                if (line.isNotBlank()) L("    $line".take(180))
            }
            val ok = p.exitValue() == 0
            L(if (ok) "[+] GhostLock 执行完成 (exit=0)" else "[-] provider 退出码 ${p.exitValue()}")
            ExecResult(if (ok) 0 else -3, log)
        } catch (e: Exception) {
            L("[-] 执行异常: ${e.message}")
            ExecResult(-4, log)
        }
    }
}
