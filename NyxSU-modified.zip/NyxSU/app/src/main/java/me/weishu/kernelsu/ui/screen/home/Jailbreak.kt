package me.weishu.kernelsu.ui.screen.home

import androidx.annotation.StringRes
import me.weishu.kernelsu.R
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Popular jailbreak / privilege-escalation methods surfaced in the jailbreak dialog.
 *
 * [exec] maps each method onto a REAL ksud invocation:
 *  - LATE_LOAD  : `ksud late-load --magica 5555 --package-name <pkg>` (kernel LKM injection)
 *  - LATE_LOAD_SHELL : same + allow-shell semantics via MagicaService path
 *  - SHIZUKU    : trigger through the Shizuku service if paired
 */
enum class JailbreakMethod(
    @StringRes val labelRes: Int,
    @StringRes val descRes: Int,
    val exec: ExecKind,
) {
    DIRTY_FRAG(R.string.jailbreak_method_dirtyfrag, R.string.jailbreak_method_dirtyfrag_desc, ExecKind.LATE_LOAD),
    GHOSTLOCK(R.string.jailbreak_method_ghostlock, R.string.jailbreak_method_ghostlock_desc, ExecKind.LATE_LOAD),
    GHOST_KEY(R.string.jailbreak_method_ghostkey, R.string.jailbreak_method_ghostkey_desc, ExecKind.LATE_LOAD),
    DIRTY_PIPE(R.string.jailbreak_method_dirtypipe, R.string.jailbreak_method_dirtypipe_desc, ExecKind.LATE_LOAD),
    DIRTY_COW(R.string.jailbreak_method_dirtycow, R.string.jailbreak_method_dirtycow_desc, ExecKind.LATE_LOAD),
    SHIZUKU(R.string.jailbreak_method_shizuku, R.string.jailbreak_method_shizuku_desc, ExecKind.SHIZUKU),
}

enum class ExecKind { LATE_LOAD, SHIZUKU }

enum class JailbreakMode(val value: String, @StringRes val labelRes: Int) {
    ULTRA("ultra", R.string.jailbreak_mode_ultra),
    NORMAL("normal", R.string.jailbreak_mode_normal);
}

object JailbreakLogStore {
    private val lines = ArrayDeque<String>()
    const val MAX_LINES = 200

    @Synchronized
    fun append(line: String) {
        lines.addLast(line)
        while (lines.size > MAX_LINES) lines.removeFirst()
    }

    @Synchronized
    fun snapshot(): List<String> = lines.toList()

    @Synchronized
    fun clear() = lines.clear()
}

/** Run a command through the (unprivileged) shell. Works before root is granted. */
private fun sh(cmd: String): String = try {
    val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
    val out = BufferedReader(InputStreamReader(p.inputStream)).readText().trim()
    p.waitFor()
    out
} catch (_: Throwable) {
    ""

}

private fun kernelVersion(): Pair<Int, Int>? {
    val uname = sh("uname -r")
    val m = Regex("(\\d+)\\.(\\d+)").find(uname) ?: return null
    return (m.groupValues[1].toIntOrNull() ?: 0) to (m.groupValues[2].toIntOrNull() ?: 0)
}

private fun hasKpm(): Boolean = sh("ls /proc/kpm >/dev/null 2>&1 && echo yes").contains("yes")

private fun hasShizuku(): Boolean {
    val p = sh("dumpsys package rikka.shizuku 2>/dev/null | grep -m1 versionName")
    if (p.isNotBlank()) return true
    return sh("ps -A 2>/dev/null | grep -i shizuku").isNotBlank()
}

/**
 * Probe whether the current kernel/device supports [method].
 * Returns log lines describing the result; the last line starts with
 * "OK" when supported or "FAIL" when not.
 */
private var appContext: android.content.Context? = null
fun setProbeContext(c: android.content.Context) { appContext = c.applicationContext }
private fun context(): android.content.Context = appContext
    ?: throw IllegalStateException("probe context not initialised")

fun probeJailbreak(method: JailbreakMethod): List<String> {
    val log = mutableListOf<String>()
    log += "[*] 目标方式: $method"
    log += "[*] 内核版本: ${sh("uname -r").ifBlank { "unknown" }}"

    val supported = when (method) {
        JailbreakMethod.DIRTY_FRAG, JailbreakMethod.GHOSTLOCK, JailbreakMethod.GHOST_KEY -> {
            val kpm = hasKpm()
            if (kpm) {
                log += "[+] 检测到 KPM 内核接口 (/proc/kpm)"
            } else {
                // Kernel has no KPM interface: these patch-based methods cannot
                // run, but this device may still be servable by GhostLock's
                // per-device profile database or Shizuku. Suggest alternatives
                // instead of a bare failure.
                log += "[-] 当前内核无 KPM 接口, 内核补丁类方式不可用"
                val gl = JailbreakAssets.checkGhostlockProfile(context())
                if (gl != null) {
                    log += "[✓] 建议: 你的内核在 GhostLock 档案库中 → 请选择 Ghostlock"
                } else if (hasShizuku()) {
                    log += "[✓] 建议: 检测到 Shizuku → 请选择 NyxSU_Shizuku"
                } else {
                    log += "[✓] 建议: 安装 Shizuku 并配对后选择 NyxSU_Shizuku (全设备可用)"
                }
            }
            kpm
        }
        JailbreakMethod.DIRTY_PIPE -> {
            val v = kernelVersion()
            val ok = v != null && (v.first < 5 || (v.first == 5 && v.second <= 16))
            log += if (ok) "[+] 内核版本命中 DirtyPipe (CVE-2022-0847) 影响范围" else "[-] 内核版本高于 5.16, DirtyPipe 不可用"
            ok
        }
        JailbreakMethod.DIRTY_COW -> {
            val v = kernelVersion()
            val ok = v != null && v.first < 5
            log += if (ok) "[+] 内核版本命中 DirtyCow (CVE-2016-5195) 影响范围" else "[-] 内核版本较新, DirtyCow 不可用"
            ok
        }
        JailbreakMethod.SHIZUKU -> {
            val ok = hasShizuku()
            log += if (ok) "[+] 检测到 Shizuku 服务, 可直接下发提权指令" else "[-] 未检测到 Shizuku, 请先配对并启动 Shizuku"
            ok
        }
    }
    log += if (supported) "OK jailbreak supported" else "FAIL kernel not supported"
    return log
}
