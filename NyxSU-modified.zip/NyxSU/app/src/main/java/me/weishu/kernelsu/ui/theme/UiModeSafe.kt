package me.weishu.kernelsu.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import me.weishu.kernelsu.ui.LocalUiMode
import me.weishu.kernelsu.ui.UiMode
import top.yukonga.miuix.kmp.theme.MiuixTheme

/**
 * UI-mode-safe theme access helpers.
 *
 * RULE: code shared between the Miuix and Material UIs MUST NOT read
 * `MiuixTheme.colorScheme` (or any other Miuix CompositionLocal) directly.
 * Under the Material theme those CompositionLocals are not provided, so a
 * direct read throws `IllegalStateException` and crashes the app on switch.
 *
 * Always branch on [LocalUiMode] through the helpers below instead.
 */

@Composable
fun uiModeAwareColor(miuix: Color, material: Color): Color =
    when (LocalUiMode.current) {
        UiMode.Miuix -> miuix
        UiMode.Material -> material
    }

@Composable
fun uiModeAwareSurfaceColor(): Color =
    when (LocalUiMode.current) {
        UiMode.Material -> MaterialTheme.colorScheme.surface
        UiMode.Miuix -> MiuixTheme.colorScheme.surface
    }

@Composable
fun uiModeAwareOnSurfaceColor(): Color =
    when (LocalUiMode.current) {
        UiMode.Material -> MaterialTheme.colorScheme.onSurface
        UiMode.Miuix -> MiuixTheme.colorScheme.onSurface
    }

@Composable
fun uiModeAwareSurfaceContainerColor(): Color =
    when (LocalUiMode.current) {
        UiMode.Material -> MaterialTheme.colorScheme.surfaceContainer
        UiMode.Miuix -> MiuixTheme.colorScheme.surfaceContainer
    }

@Composable
fun uiModeAwarePrimaryColor(): Color =
    when (LocalUiMode.current) {
        UiMode.Material -> MaterialTheme.colorScheme.primary
        UiMode.Miuix -> MiuixTheme.colorScheme.primary
    }
