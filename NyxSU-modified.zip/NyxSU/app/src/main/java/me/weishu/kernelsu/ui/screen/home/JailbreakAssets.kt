package me.weishu.kernelsu.ui.screen.home

import android.content.Context
import java.io.File

/**
 * Real jailbreak asset staging.
 *
 * Ships the GhostLock kernel-profile database (84 real per-device kernel
 * offset profiles from the open-source ghostlock-app project) plus the
 * DirtyFrag bootstrap / GhostLock provider / L3 su binaries, stages them
 * under /data/local/tmp/nyxsu at activation time, and hands the profile
 * path to the provider binary exactly like MapleSU does.
 */
object JailbreakAssets {

    const val STAGE_DIR = "/data/local/tmp/nyxsu"

    fun stageBinaries(context: Context, log: (String) -> Unit): Boolean {
        return try {
            val dir = File(STAGE_DIR)
            dir.mkdirs()
            val names = listOf(
                "dirtyfrag_bootstrap.so",
                "ghostlock_provider.so",
                "l3_su.so",
                "dfroot.so",
                "root_consumer.so",
            )
            for (n in names) {
                val inp = context.assets.open("nyxsu/$n")
                val out = File(dir, n)
                out.outputStream().use { o -> inp.copyTo(o) }
                inp.close()
                // binaries must be executable for the provider to exec
                Runtime.getRuntime().exec(arrayOf("chmod", "700", out.absolutePath)).waitFor()
                log("[+] staged $n (${out.length()}B)")
            }
            true
        } catch (e: Exception) {
            log("[-] staging failed: ${e.message}")
            false
        }
    }

    /** Find the GhostLock profile matching this device's exact uname -r. */
    fun findGhostlockProfile(context: Context, kernelRelease: String): String? {
        val safe = kernelRelease.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val direct = "nyxsu/ghostlock/$kernelRelease.conf"
        return try {
            context.assets.open(direct).use { inp ->
                val dir = File(STAGE_DIR)
                dir.mkdirs()
                val out = File(dir, "ghostlock.conf")
                out.outputStream().use { o -> inp.copyTo(o) }
                out.absolutePath
            }
        } catch (_: Exception) {
            try {
                // tolerate path sanitisation differences
                context.assets.open("nyxsu/ghostlock/$safe.conf").use { inp ->
                    val out = File(STAGE_DIR, "ghostlock.conf")
                    out.outputStream().use { o -> inp.copyTo(o) }
                    out.absolutePath
                }
            } catch (_: Exception) {
                null
            }
        }
    }

    /** Run the staged GhostLock provider against a staged profile. */
    fun runGhostlock(profilePath: String, log: (String) -> Unit): Boolean {
        return try {
            val cmd = arrayOf(
                "su", "-c",
                "$STAGE_DIR/ghostlock_provider.so --load-prebuilt-profile $profilePath"
            )
            val p = Runtime.getRuntime().exec(cmd)
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.lines().forEach { if (it.isNotBlank()) log("    $it") }
            p.exitValue() == 0
        } catch (e: Exception) {
            log("[-] ghostlock exec failed: ${e.message}")
            false
        }
    }
}
